# Voxy Snow & Shallow Water Fix (Minecraft 26.3)

A small, client-side Fabric addon for Voxy. It applies the behavior proposed in [Voxy PR #726](https://github.com/MCRcortex/voxy/pull/726) without bundling or modifying Voxy's source code.

## What it fixes

Voxy's LOD mapper chooses the representative block using opacity/light-dampening values. Snow layers and liquid blocks can lose to the solid block below them, so the snow or water disappears at coarse, distant LOD levels. This addon sets the mapped opacity of leaves, snow layers, and liquid blocks to 15, matching the intended fix.

## Target environment

- Minecraft 26.3
- Fabric Loader 0.19.5 or newer
- Voxy 0.2.20-beta or newer, with a matching 26.3 build
- Java 25

This is a source project; it has not been compiled or tested in-game in the environment where it was generated.

## Build

1. Install a JDK 25 and Gradle 9.6.0 or newer.
2. Open a terminal in this project directory.
3. Run `gradle build` (Windows PowerShell can use the same command if Gradle is on `PATH`).
4. The mod JAR will be written to `build/libs/voxy-snow-fluid-fix-1.0.0.jar`.
5. Copy the JAR to the Minecraft instance's `mods` folder alongside Voxy.

The first build downloads Minecraft and Gradle dependencies, so an internet connection is required.

## Existing worlds: rebuild Voxy's generated data

The fix changes the opacity used when Voxy generates LOD data; it does not retroactively repair LOD data already generated before the addon was installed.

1. Back up the world first.
2. Remove only that world's Voxy-generated data/cache directory (do **not** delete the actual Minecraft world, region files, or player data).
3. Launch the game and run `voxy import current` to rebuild Voxy's data.

The Voxy PR author specifically noted that the existing Voxy data must be rebuilt for the visual change to appear.

## Implementation note

A Mixin injects at the tail of `Mapper.StateEntry(int, BlockState)` and updates its final `opacity` field for leaves, snow layers, and liquids. This intentionally relies on Voxy's current internal class and field names, so a future Voxy update may require an adjustment.
