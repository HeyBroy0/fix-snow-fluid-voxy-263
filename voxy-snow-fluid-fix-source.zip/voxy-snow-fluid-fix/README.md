# Voxy Snow, Water & Ice Fix (Minecraft 26.3)

A small, client-side Fabric addon for Voxy. It implements the behavior proposed in [Voxy PR #726](https://github.com/MCRcortex/voxy/pull/726) and extends it to ice, without bundling or modifying Voxy's source code.

## What it fixes

Voxy's LOD mapper uses opacity/light-dampening values when generating coarse terrain representations. Snow layers, liquids, leaves, and ordinary ice can otherwise be represented poorly at a distance. This addon sets their mapped opacity to 15 so they are more likely to remain visible in far-distance LOD terrain.

The ice check uses `IceBlock`, which includes ordinary ice and frosted ice. Packed ice and blue ice are already opaque in vanilla and are not changed by this addon.

## Target environment

- Minecraft 26.3
- Fabric Loader 0.19.5 or newer
- Voxy 0.2.20-beta or newer, with a matching 26.3 build
- Java 25 for building

## Build

This source project is built by the included GitHub Actions workflow. The workflow extracts the archive, changes the Fabric Loader dependency from `modImplementation` to `implementation` for Minecraft 26.3, installs Gradle 9.8.0, and runs `gradle build`.

The project has not been compiled or tested in this environment. The ice change requires a new build and in-game testing.

## Existing worlds: refresh Voxy LOD data if needed

The change affects the opacity Voxy uses during LOD generation. If ice still disappears after installing the new JAR, back up the world and rebuild Voxy's generated data using the instructions for your installed Voxy version. Do not delete the actual Minecraft world, region files, or player data.

## Implementation note

A Mixin injects at the end of `Mapper.StateEntry(int, BlockState)` and sets the mapped opacity for leaves, snow layers, liquids, and `IceBlock` instances. This relies on Voxy's internal class/field names; a future Voxy update may require adjustment.
