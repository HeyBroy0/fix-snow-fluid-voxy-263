package dev.voxyfix.mixin;

import net.minecraft.world.level.block.IceBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies the snow, liquid, and ice opacity correction to Voxy's block-state mapping.
 * The target class name is kept as a string so Voxy itself is not bundled.
 */
@Mixin(targets = "me.cortex.voxy.common.world.other.Mapper$StateEntry")
public abstract class StateEntryMixin {
    @Shadow @Final @Mutable public int opacity;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void voxySnowFluidFix$forceOpaqueForLod(int id, BlockState state, CallbackInfo ci) {
        if (state.getBlock() instanceof LeavesBlock
                || state.getBlock() instanceof SnowLayerBlock
                || state.getBlock() instanceof LiquidBlock
                || state.getBlock() instanceof IceBlock) {
            this.opacity = 15;
        }
    }
}
